const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const axios = require('axios');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('dist'));

const PORT = 8081;

app.post('/analyze', async (req, res) => {
    try {
        const { url } = req.body;
        const response = await axios.post('https://api.meaningcloud.com/sentiment-2.1', null, {
            params: {
                key: process.env.API_KEY,
                url,
                lang: 'en'
            }
        });
        res.json(response.data);
    } catch (error) {
        res.status(500).json({ error: 'Error analyzing text' });
    }
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});

if (!url || !isValidUrl(url)) {
    return res.status(400).json({ error: 'Invalid URL' });
}

function isValidUrl(string) {
    try {
        new URL(string);
        return true;
    } catch (_) {
        return false;
    }
}

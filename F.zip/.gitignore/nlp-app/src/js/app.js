
document.getElementById('analyze-btn').addEventListener('click', async () => {
    const url = document.getElementById('url-input').value;
    if (!isValidUrl(url)) {
        alert('Please enter a valid URL');
        return;
    }
    const response = await fetch('/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
    });
    const data = await response.json();
    document.getElementById('results').innerText = JSON.stringify(data, null, 2);
});

function isValidUrl(string) {
    try {
        new URL(string);
        return true;
    } catch (_) {
        return false;
    }
}

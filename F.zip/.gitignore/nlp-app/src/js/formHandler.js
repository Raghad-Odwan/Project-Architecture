const { isValidUrl } = require('../js/formHandler');

test('Valid URL should return true', () => {
    expect(isValidUrl('https://example.com')).toBe(true);
});

test('Invalid URL should return false', () => {
    expect(isValidUrl('invalid-url')).toBe(false);
});






module.exports = { isValidUrl };

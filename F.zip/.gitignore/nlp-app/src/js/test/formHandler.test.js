const { handleSubmit } = require('../js/formHandler');

test('handleSubmit should be defined', () => {
    expect(handleSubmit).toBeDefined();
});

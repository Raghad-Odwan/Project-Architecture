const { isValidUrl } = require('../../js/app');
 

test('isValidUrl should return true for a valid URL', () => {
    expect(isValidUrl('https://www.example.com')).toBe(true);
});

test('isValidUrl should return false for an invalid URL', () => {
    expect(isValidUrl('invalid-url')).toBe(false);
});

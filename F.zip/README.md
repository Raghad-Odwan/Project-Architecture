# NLP Web App 

## project descrption
This project is a Natural Language Processing (NLP) web application that utilizes Udacity's hosted AWS NLP API. It allows users to analyze the sentiment and meaning of text extracted from a provided URL. The application follows best practices in web development, including webpack bundling, service workers for offline functionality, and Jest testing.

## Instructions  
How to Run the App

### Prerequisites
Node.js installed
npm installed

### Installation Steps
Clone the repository:
git clone https://github.com/your-repo-url.git
cd your-repo-folder

Install dependencies:
npm install

Run the development server:
npm run dev

Build for production:
npm run build

Start the production server:
npm run start
